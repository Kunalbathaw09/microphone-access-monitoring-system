Microphone Access Monitoring System

This project detects and monitors unauthorized microphone usage in a browser.

Features:
- Microphone permission detection
- Real-time monitoring
- Sound level detection
- Suspicious activity alerts
- Admin login system
- Security dashboard

Technologies:
HTML
CSS
JavaScript
Web Audio API