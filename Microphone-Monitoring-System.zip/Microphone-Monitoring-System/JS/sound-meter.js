let audioContext;
let analyser;
let microphone;

async function initMic(){

const stream = await navigator.mediaDevices.getUserMedia({audio:true});

audioContext = new AudioContext();

microphone = audioContext.createMediaStreamSource(stream);

analyser = audioContext.createAnalyser();

microphone.connect(analyser);

monitorSound();

}

function monitorSound(){

let dataArray = new Uint8Array(analyser.frequencyBinCount);

analyser.getByteFrequencyData(dataArray);

let values = 0;

for(let i=0;i<dataArray.length;i++){

values += dataArray[i];

}

let average = values / dataArray.length;

document.getElementById("soundLevel").innerText = Math.round(average) + " dB";

if(average > 80){

logEvent("High Sound Level","Suspicious");

}

requestAnimationFrame(monitorSound);

}

initMic();