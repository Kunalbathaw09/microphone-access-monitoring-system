function login(){

let user=document.getElementById("username").value;

let pass=document.getElementById("password").value;

if(user==="admin" && pass==="1234"){

localStorage.setItem("admin","true");

window.location.href="dashboard.html";

}

else{

document.getElementById("msg").innerText="Invalid login";

}

}