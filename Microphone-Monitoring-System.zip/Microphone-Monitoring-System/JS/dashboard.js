let accessCount = 0;
let suspiciousCount = 0;

function logEvent(event,status){

let table = document.getElementById("logTable");

let row = `
<tr>
<td>${new Date().toLocaleTimeString()}</td>
<td>${event}</td>
<td>${status}</td>
</tr>
`;

table.innerHTML += row;

}


function startMonitoring(){

logEvent("Monitoring Started","Normal");

}


function stopMonitoring(){

logEvent("Monitoring Stopped","Normal");

}



const ctx = document.getElementById('activityChart');

new Chart(ctx, {
type: 'line',
data: {
labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
datasets: [{
label: 'Microphone Activity',
data: [2,4,3,6,5,7,4],
borderWidth: 2
}]
},
options: {
responsive:true
}
});