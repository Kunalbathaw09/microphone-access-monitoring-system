let stream = null;

function addLog(message){

const logList = document.getElementById("logs");

const li = document.createElement("li");

li.textContent = new Date().toLocaleTimeString()+" - "+message;

logList.appendChild(li);

}

async function checkMic(){

try{

await navigator.mediaDevices.getUserMedia({audio:true});

document.getElementById("status").innerText="Microphone Access Granted";

addLog("Microphone permission granted");

}

catch{

document.getElementById("status").innerText="Microphone Access Denied";

addLog("Microphone permission denied");

}

}

async function startMonitoring(){

try{

stream = await navigator.mediaDevices.getUserMedia({audio:true});

addLog("Microphone monitoring started");

}

catch{

addLog("Monitoring failed");

}

}

function stopMonitoring(){

if(stream){

stream.getTracks().forEach(track=>track.stop());

addLog("Monitoring stopped");

}

}