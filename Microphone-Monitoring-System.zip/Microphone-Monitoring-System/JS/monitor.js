let audioContext;
let analyser;
let microphone;
let javascriptNode;
let soundChart;
let chartData=[];

function createChart(){

const ctx=document.getElementById("soundChart");

soundChart=new Chart(ctx,{
type:"line",

data:{
labels:[],
datasets:[{
label:"Sound Level",
data:[],
borderColor:"#22c55e",
borderWidth:2
}]
},

options:{
responsive:true,
scales:{
y:{
beginAtZero:true,
max:100
}
}
}

});

}

window.onload=createChart;

async function startMonitoring(){

document.getElementById("micStatus").innerText="ON";

const stream=await navigator.mediaDevices.getUserMedia({audio:true});

audioContext=new AudioContext();

analyser=audioContext.createAnalyser();

microphone=audioContext.createMediaStreamSource(stream);

javascriptNode=audioContext.createScriptProcessor(2048,1,1);

microphone.connect(analyser);

analyser.connect(javascriptNode);

javascriptNode.connect(audioContext.destination);

javascriptNode.onaudioprocess=function(){

let array=new Uint8Array(analyser.frequencyBinCount);

analyser.getByteFrequencyData(array);

let values=0;

for(let i=0;i<array.length;i++){

values+=array[i];

}

let average=values/array.length;

document.getElementById("soundLevel").innerText=Math.round(average);

updateGraph(average);

if(average>70){

addLog("⚠ Suspicious sound detected");

}

}

}

function stopMonitoring(){

document.getElementById("micStatus").innerText="OFF";

if(audioContext){

audioContext.close();

}

addLog("Monitoring stopped");

}

function updateGraph(value){

soundChart.data.labels.push("");

soundChart.data.datasets[0].data.push(value);

if(soundChart.data.labels.length>20){

soundChart.data.labels.shift();

soundChart.data.datasets[0].data.shift();

}

soundChart.update();

}

function addLog(message){

const logList=document.getElementById("logs");

const li=document.createElement("li");

li.textContent=new Date().toLocaleTimeString()+" - "+message;

logList.appendChild(li);

}